/**
 * upload 向服务端上传文件
 * @param file object 文件对象
 * @return object xml对象
 */
const upload=(file)=>{
    const url="/api/files/upload";
//     服务端api地址
    xml=new XMLHttpRequest();
//     实例异步请求对象
    xml.open("POST",url,true);
//     发送请求
    fd=new FormData();
    fd.append("img",file);
    xml.send(fd);
    return xml;
}

/**
 * showLoadBar 展示进度条遮罩
 */
const showLoadBar=function(){
    let dom=document.getElementById("load");
    dom.style.display="flex";
    changeJdt(0)
}
/**
 * showLoadBar 隐藏进度条遮罩
 */
const hideLoadBar=function(){
    let dom=document.getElementById("load");
    dom.style.display="none";
    changeJdt(0);
}
/**
 * changeJdt 修改进度条进度
 * @param w 进度图进度百分比
 */
const changeJdt=function(w){
    w= w<0 ? 0 : w;
    w= w>100 ? 100 : w;
    let jdt=document.querySelector("#jdt").getElementsByClassName("jdt-ft")[0];
    jdt.style.width=w+"%";
    return w;
}
const ajaxFinished=function(xml){
    // 封装ajax完成事件
    if(xml.status===200){
        let data=JSON.parse(xml.responseText);
        if (data.status==="success"){
            //     修改img-container为预览图像
            let dom=document.querySelector("#img-container");
            dom.innerHTML="<img src='"+data.url+"' style='max-width:100%;height:auto' />";
            //   生成html代码
            let htmlstr=`&lt;img src="${data.url}" title="小杜的图床" alt='图床无拉！'&gt;`;
            // 写入DOM
            document.querySelector("#htmlcode").innerHTML=htmlstr;
            // 生成md代码
            let mdstr=`![小杜的个人图床](${data.url})`;
            // 写入DOM
            document.querySelector("#mdcode").innerHTML=mdstr;
            //     显示上传信息
            document.getElementsByClassName('result-box')[0].style.display="block";
        }else{
            alert(data.msg);
            window.history.back();
        }
    }
}
/**
 * dropFile 拖动图片到浏览器的事件函数
 * @param e object 事件对象
 */
const dropFile=(e)=>{
    // 获得文件对象
    let file=e.dataTransfer.files[0];
//     异步上传图片
    let xml=upload(file);
    // 显示进度条遮罩
    showLoadBar();
    // 不知道为什么这里是个不可计算长度的数据，只能做个假的进度条了。
        var s=10;
        window.jsq=setInterval(function(){
        s=changeJdt(s)+5;
        },50)
    // 上传完成事件
    xml.onload=()=>{
        //     隐藏进度条遮罩
        hideLoadBar();
        //     销毁计时器
        clearInterval(window.jsq);
        //     预览图像
        ajaxFinished(xml);

    }
}
/**
 * pasteFile拖动图片到浏览器的事件函数
 * @param e object 事件对象
 */
const pasteFile=(e)=>{
    // 获得文件对象
    let file=e.clipboardData.files[0] || window.clipboardData.files[0];
//     异步上传图片
    let xml=upload(file);
    // 显示进度条遮罩
    showLoadBar();
    // 控制进度条变化
    // console.log(xml.upload)
    // 不知道为什么这里是个不可计算长度的数据，只能做个假的进度条了。
    var s=10;
    window.jsq=setInterval(function(){
        s=changeJdt(s)+5;
    },50)
    // 上传完成事件
    xml.onload=()=>{
        //     隐藏进度条遮罩
        hideLoadBar();
        //     销毁计时器
        clearInterval(window.jsq);
        //     预览图像
        ajaxFinished(xml);

    }
}
const clickFile=()=>{
    // 获得文件对象
    let file=input.files[0];
//     异步上传图片
    let xml=upload(file);
    // 显示进度条遮罩
    showLoadBar();
    // 控制进度条变化
    // console.log(xml.upload)
    // 不知道为什么这里是个不可计算长度的数据，只能做个假的进度条了。
    var s=10;
    window.jsq=setInterval(function(){
        s=changeJdt(s)+5;
    },50)
    // 上传完成事件
    xml.onload=()=>{
        //     隐藏进度条遮罩
        hideLoadBar();
        //     销毁计时器
        clearInterval(window.jsq);
        //     预览图像
        ajaxFinished(xml);
    }
}


let node=document.querySelector("#img-container");
// 取得图片容器元素
let input=document.querySelector("#click-file");
// 取得输入框元素
// 监听事件
window.onload=()=>{
    // 拖放事件
    document.addEventListener("drop",function(e){
        dropFile(e);
        // 禁用拖放，事件监听在文档对象防止用户没有将图片拖动到元素上
        e.preventDefault();
    });
    // 禁用拖放移动
    document.addEventListener("dragover",function(e){
        e.preventDefault();
    })
    // 监听粘贴事件
    node.addEventListener("paste",function(e){
        pasteFile(e);
    });
//     监听点击事件
    input.addEventListener("change",function(e){
        clickFile(e)
    });
}