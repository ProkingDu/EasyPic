<?php

$e=$_POST['e'];
return $e;
?>